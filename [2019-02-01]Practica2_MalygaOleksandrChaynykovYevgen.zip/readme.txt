Oleksandr Malyga y Yevgen Chaynykov
Acceso a datos, Desarrollo de Aplicaciones Multiplataforma, 01/02/2019

Para poder usar el programa es necesario instalar XAMPP con MariaDB 10.1.37.
Hibernate está configurado para trabajar con el usuario "root" y contraseña "" (vacía).

En la carpeta exes hemos incluído el fichero SQL.txt, el cual contiene todos los comandos para crear la base de datos y las tablas, y para insertar todos los registros necesarios para el programa.
Hay que copiar todo el contenido del fichero y pegarlo en la consola SQL de PHPMYADMIN.

Una vez ejecutados todos los comándos del fichero y encendida la base de datos, se podrá usar el programa.